# SPDX-FileCopyrightText: 2025-present Mikhail <725156@gmail.com>
#
# SPDX-License-Identifier: MIT

# Импортируем все классы из подпапок в одном модуле для удобства
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

# Отключить absl/низкоуровневые варнинги
try:
    import absl.logging
    absl.logging.set_verbosity(absl.logging.ERROR)
except ImportError:
    pass

from .__about__ import __version__
from .unit_conversion import triangle_to_matr, detect_unit, convert
from .concentration_solver import fpi_step, find_equilibrium_conc
from .oligama.predictors.affinity_predictors import Nupack_Affinity_Predictor
from .oligama.predictors.hairpin_predictors import Nupack_Hairpin_Predictor
from .oligama.scripts.affinity_matrix import Affinity_Matrix
from .oligama.scripts.complex_solver import Complex_Solver
from .oligama.scripts.olig_finder import Olig_Finder
from .oligama.scripts.concentration_solver import Concentration_Solver as Primary_Concentration_Solver
from .oligama.scripts.complement import Complement
from .oligama.scripts.random_initializer import Random_Initializer
from .oligama.scripts.gene_olig_finder import Gene_Olig_Finder
from .oligama.scripts.microrna_finder import MicroRNA_Finder
from .oligama.utils import random_seq, compl, mutate_x_letters
from .oligama.scripts.oligs_finder_bash import AddOligsNew


__all__ = [
    #unit_conversion
    "triangle_to_matr",
    "detect_unit",
    "convert",
    #concentration_solver
    "fpi_step",
    "find_equilibrium_conc",
    #oligama
    "Nupack_Affinity_Predictor",
    "Nupack_Hairpin_Predictor",
    "Affinity_Matrix",
    "Complex_Solver",
    "Olig_Finder",
    "Primary_Concentration_Solver",
    "Complement",
    "Random_Initializer",
    "Gene_Olig_Finder",
    "MicroRNA_Finder",
    "random_seq",
    "compl",
    "mutate_x_letters",
    "AddOligsNew"
]
