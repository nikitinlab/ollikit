# -*- coding: utf-8 -*-
# ──────────────────────────────────────────────────────────────────────────────
# seqfold/__init__.py
# Замена устаревшего pkg_resources → importlib.metadata
# (будет работать и на Python < 3.8 через back-port importlib-metadata)
# ──────────────────────────────────────────────────────────────────────────────
try:
    # Python ≥ 3.8
    from importlib.metadata import version, PackageNotFoundError
except ImportError:                     # pragma: no cover  – для старых интерпретаторов
    from importlib_metadata import version, PackageNotFoundError  # pip install importlib-metadata

try:
    dist_name = __name__               # если пакет переименуют – меняем  здесь
    __version__ = version(dist_name)
except PackageNotFoundError:
    __version__ = "unknown"

# ──────────────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────────────
from .fold import fold, dg, dg_cache, Struct, dot_bracket
from .tm import tm, tm_cache, gc_cache
from .types import Cache
