# SPDX-FileCopyrightText: 2025-present Mikhail <725156@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.1"
