# ollikit

[![PyPI - Version](https://img.shields.io/pypi/v/ollikit.svg)](https://pypi.org/project/ollikit)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/ollikit.svg)](https://pypi.org/project/ollikit)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install ollikit
```

## License

`ollikit` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
